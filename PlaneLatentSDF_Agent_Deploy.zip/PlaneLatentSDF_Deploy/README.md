# PlaneLatentSDF 部署包

先读 `AGENT_DEPLOYMENT.md`，再运行 `python verify_core.py`。主配置为 `config.json`。

核心已经实现：plane MLP编码、物理距离latent插值、单标量query decoder、真实/留一层监督、EMA分布蒸馏、二阶法向正则、接缝约束、完整三维Eikonal、训练及Marching Cubes。

必须由部署agent完成的对接：把已有MnM2对齐SAX缓存映射为文档中的manifest或NPZ。没有提供真实缓存字节，不能声称已经完成这个字段映射。代码内 `TODO` 指出需要核对的事项，核心函数不是空实现。

```bash
python -m pip install -r requirements.txt
python verify_core.py
python make_synthetic.py --output synthetic
python train.py --data synthetic --output runs/smoke --device cpu --epochs 1 --max-steps 1
```

上面的短训练只确认入口运行；所有loss开启的梯度检查在verify中。`verification.json`和`smoke_validation.json`记录本包已执行的验证，不是临床效果报告。

真实部署：

```bash
python prepare_cache.py --manifest aligned_sax_manifest.json --output data/plane_sdf
python train.py --data data/plane_sdf --output runs/main --device cuda
python extract_mesh.py --checkpoint runs/main/best.pt --case data/plane_sdf/test/patient_001_ED.npz --output outputs/patient_001_ED.obj
```

注意：二维轮廓SDF不是精确三维距离；EMA教师不接受梯度；Eikonal必须求包含latent位置插值的完整场梯度。默认只重建观测stack轴向范围，端部可能开放；人工封口需显式 `--cap-stack`，不能当成真实端部恢复。详见部署文档。
